from turtle import shape
import numpy as np
from numpy import int64

posit1=np.arange(5).repeat(3).reshape(5,3).transpose(1,0)
print(posit1)



